<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Fahad</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="freehtml5.co" />

	<!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FreeHTML5.co
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Space+Mono" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="fh5co-loader"></div>
	
	<div id="page">	
	<header id="fh5co-header" class="fh5co-cover js-fullheight" role="banner" style="background-image:url(images/cover_bg_3.jpg);" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="display-t js-fullheight">
						<div class="display-tc js-fullheight animate-box" data-animate-effect="fadeIn">
							<div class="profile-thumb" style="background: url(images/profile.jpg);"></div>
							<h1><span>Fahad</span></h1>
							<h3><span>Web Developer </span></h3>
							<p>
								<ul class="fh5co-social-icons">
									<li><a href="https://twitter.com/fahad2109"><i class="icon-twitter2"></i></a></li>
									<li><a href="https://www.facebook.com/profile.php?id=100059394901669"><i class="icon-facebook2"></i></a></li>
									<li><a href="https://www.linkedin.com/in/fahad-binsadique-3b63211b5/"><i class="icon-linkedin2"></i></a></li>
									<li><a href="https://www.reddit.com/user/tinybear07"><i class="icon-reddit"></i></a></li>
								</ul>
							<div>
								<br>
								<h3>Checkout My Profiles</h3>

								<a href="https://www.fiverr.com/fahad2109"><img style="height: 58px;" src="images/fiverr-vector-logo.svg"></a>
								<a href="https://www.upwork.com/freelancers/~019442b5a15b10a65a"><img style="height: 19px; margin-top: 2px;" src="images/upwork.svg"></a>

								
							</div>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<div id="fh5co-about" class="animate-box">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>About Me</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<ul class="info">
						<li><span class="first-block">Full Name:</span><span class="second-block">Md Fahad Mia</span></li>
						<li><span class="first-block">Phone:</span><span class="second-block">+8801980497577</span></li>
						<li><span class="first-block">Email:</span><span class="second-block">fahadm2109@gmail.com</span></li>
						<li><span class="first-block">Website:</span><span class="second-block">www.blogdesire.com</span></li>
						<li><span class="first-block">Address:</span><span class="second-block">Dhaka,Bangladesh</span></li>
					</ul>
				</div>
				<div class="col-md-8">
					<h2>Hello Sir</h2>
					<p></p>
					<p>I am passionate at Web Development. With PHP, MySQL,jQuery, Bootstrap, Fontawsome,With some attractive and powerful template i am able to build attractive and web applications. I have built a few personal web applications and worked with a broad leveled group with i have gathered a huge amount experience. I have worked for 3 years.I can provide you nice admin panel from where you can control your website. Blog website, e-commerce website, and other web platforms can be built with some extra features using api integration. Thank you</p>
					<p>
						<ul class="fh5co-social-icons">
							<li><a href="https://twitter.com/fahad2109"><i class="icon-twitter2"></i></a></li>
							<li><a href="https://www.facebook.com/profile.php?id=100059394901669"><i class="icon-facebook3"></i></a></li>
							<li><a href="https://www.linkedin.com/in/fahad-binsadique-3b63211b5"><i class="icon-linkedin2"></i></a></li>
							<li><a href="https://www.reddit.com/user/tinybear07"><i class="icon-reddit"></i></a></li>
						</ul>
					</p>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-resume" class="fh5co-bg-color">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>My Resume</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 col-md-offset-0">
					<ul class="timeline">
						<li class="timeline-heading text-center animate-box">
							<div><h3>Work Experience</h3></div>
						</li>
						<li class="animate-box timeline-unverted">
							<div class="timeline-badge"><i class="icon-suitcase"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
									<h3 class="timeline-title">Web Developer</h3>
									<span class="company">Fiverr - 2020 - Current</span>
								</div>
								<div class="timeline-body">
									<p>With PHP MySQL and Bootstrap i can build any Blog, E-commerce,Bussiness Website</p>
								</div>
							</div>
						</li>
						<li class="timeline-inverted animate-box">
							<div class="timeline-badge"><i class="icon-suitcase"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
									<h3 class="timeline-title">Mobile App Developer</h3>
									<span class="company">On progress</span>
								</div>
								<div class="timeline-body">
									<p>With Flutter and Firebase Database i can build amazing Mobile Applications</p>
								</div>
							</div>
						</li>


						<br>
						<li class="timeline-heading text-center animate-box">
							<div><h3>Education</h3></div>
						</li>
						<li class="timeline-inverted animate-box">
							<div class="timeline-badge"><i class="icon-graduation-cap"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
									<h3 class="timeline-title">Bachelors Degree</h3>
									<span class="company">East West University - 2021 - Current</span>
								</div>
								<div class="timeline-body">
									<p>Currently I am doing: 
										 B.Sc In ICE (Information and Communication Engineering) in East West University under the Department of ECE(B.Eng)</p>
								</div>
							</div>
						</li>
						<li class="animate-box timeline-unverted">
							<div class="timeline-badge"><i class="icon-graduation-cap"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
									<h3 class="timeline-title">Higher Secondary</h3>
									<span class="company">Hazi Abed Ali College - 2018 - 2020</span>
								</div>
								<div class="timeline-body">
									<p>I have finished my Higher Secondary Level From Hazi Abed Ali College</p>
								</div>
							</div>
						</li>

			    	</ul>
				</div>
			</div>
		</div>
	</div>
	

	<div id="fh5co-features" class="animate-box">
		<div class="container">
			<div class="services-padding">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>My Services</h2>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 text-center">
						<div class="feature-left">
							<span class="icon">
								<i class="icon-paintbrush"></i>
							</span>
							<div class="feature-copy">
								<h3>Web Design</h3>
								<p>With the Help of BootStrap and other libraries i have the ability to Design Cool FrontEnd</p>
							</div>
						</div>
					</div>

					<div class="col-md-4 text-center">
						<div class="feature-left">
							<span class="icon">
								<i class="icon-genius"></i>
							</span>
							<div class="feature-copy">
								<h3>App Development</h3>
								<p>I have Experties in Flutter and Firebase and with that i can build Mobile Apps</p>
							</div>
						</div>

					</div>
					<div class="col-md-4 text-center">
						<div class="feature-left">
							<span class="icon">
								<i class="icon-embed2"></i>
							</span>
							<div class="feature-copy">
								<h3>PHP Backend</h3>
								<p>I have a good knowledge in PHP backend</p>
							</div>
						</div>
					</div>
				</div>



			</div>
		</div>
	</div>

	<div id="fh5co-skills" class="animate-box">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Skills</h2>
				</div>
			</div>
			<div class="row row-pb-md">
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="84"><span><strong>HTML5</strong>84%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="75"><span><strong>CSS3</strong>75%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="86"><span><strong>jQuery</strong>86%</span></div>
				</div>

				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="89"><span><strong>PHP</strong>89%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="82"><span><strong>MySQL</strong>82%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="86"><span><strong>JavaScript</strong>86%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="55"><span><strong>Flutter</strong>55%</span></div>
				</div>
				<div class="col-md-3 col-sm-6 col-xs-12 text-center">
					<div class="chart" data-percent="83"><span><strong>MongoDB</strong>83%</span></div>
				</div>
			</div>

		</div>
	</div>

	<div id="fh5co-work" class="fh5co-bg-dark">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Work</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-3 text-center col-padding animate-box">
					<a href="#" class="work" style="background-image: url(images/E-Com-1.png);">
						<div class="desc">
							<h3>E-Commerce Website</h3>
							<span>PHP MySQL</span>
						</div>
					</a>
				</div>
				<div class="col-md-3 text-center col-padding animate-box">
					<a href="#" class="work" style="background-image: url(images/E-Com-2.png);">
						<div class="desc">
						<h3>E-Commerce Website</h3>
							<span>PHP MySQL</span>
						</div>
					</a>
				</div>
				<div class="col-md-3 text-center col-padding animate-box">
					<a href="#" class="work" style="background-image: url(images/Chatapp.png);">
						<div class="desc">
							<h3>Chat Application</h3>
							<span>PHP MySQL Jquery Ajax</span>
						</div>
					</a>
				</div>
				<div class="col-md-3 text-center col-padding animate-box">
					<a href="#" class="work" style="background-image: url(images/E-Com-3.png);">
						<div class="desc">
							<h3>E-Commerce Website</h3>
							<span>PHP MySQL JavaScript</span>
						</div>
					</a>
				</div>

			</div>
		</div>
	</div>

	<!-- <div id="fh5co-blog">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Post on Medium</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#" class="blog-bg" style="background-image: url(images/portfolio-1.jpg);"></a>
						<div class="blog-text">
							<span class="posted_on">Mar. 15th 2016</span>
							<h3><a href="#">Photoshoot On The Street</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
							<ul class="stuff">
								<li><i class="icon-heart2"></i>249</li>
								<li><i class="icon-eye2"></i>308</li>
								<li><a href="#">Read More<i class="icon-arrow-right22"></i></a></li>
							</ul>
						</div> 
					</div>
				</div>
				<div class="col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#" class="blog-bg" style="background-image: url(images/portfolio-2.jpg);"></a>
						<div class="blog-text">
							<span class="posted_on">Mar. 15th 2016</span>
							<h3><a href="#">Surfing at Philippines</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
							<ul class="stuff">
								<li><i class="icon-heart2"></i>249</li>
								<li><i class="icon-eye2"></i>308</li>
								<li><a href="#">Read More<i class="icon-arrow-right22"></i></a></li>
							</ul>
						</div> 
					</div>
				</div>
				<div class="col-md-4">
					<div class="fh5co-blog animate-box">
						<a href="#" class="blog-bg" style="background-image: url(images/portfolio-3.jpg);"></a>
						<div class="blog-text">
							<span class="posted_on">Mar. 15th 2016</span>
							<h3><a href="#">Capture Living On Uderwater</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
							<ul class="stuff">
								<li><i class="icon-heart2"></i>249</li>
								<li><i class="icon-eye2"></i>308</li>
								<li><a href="#">Read More<i class="icon-arrow-right22"></i></a></li>
							</ul>
						</div> 
					</div>
				</div>
			</div>
		</div>
	</div> -->
	
	<div id="fh5co-started" class="fh5co-bg-dark">
		<div class="overlay"></div>
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Hire Me!</h2>
					<p>I loves to do these stuffs</p>
					<p><a href="#" class="btn btn-default btn-lg">Contact Us</a></p>
				</div>
			</div>
		</div>
	</div>

	<div id="fh5co-consult">
		<div class="video fh5co-video" style="background-image: url(images/cover_bg_1.jpg);">
			<div class="overlay"></div>
		</div>
		<div class="choose animate-box">
			<h2>Contact</h2>
			<form action="mailto:fahadm2109@gmail.com">
				<div class="row form-group">
					<div class="col-md-6">
						<input type="text" id="fname" class="form-control" placeholder="Your firstname">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-md-6">
						<input type="text" id="lname" class="form-control" placeholder="Your lastname">
					</div>
				</div>

				<div class="row form-group">
					<div class="col-md-12">
						<input type="text" id="email" class="form-control" placeholder="Your email address">
					</div>
				</div>

				<div class="row form-group">
					<div class="col-md-12">
						<input type="text" id="subject" class="form-control" placeholder="Your subject of this message">
					</div>
				</div>

				<div class="row form-group">
					<div class="col-md-12">
						<textarea name="message" id="message" cols="30" rows="10" class="form-control" placeholder="Say something about us"></textarea>
					</div>
				</div>
				<div class="form-group">
					<input type="submit" value="Send Message" class="btn btn-primary">
				</div>

			</form>	
		</div>
	</div>


	
	<div id="fh5co-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p style="margin-left: 22px;">         Stay Connected :
 
						<ul class="fh5co-social-icons">
							<li><a href="https://twitter.com/fahad2109"><i class="icon-twitter2"></i></a></li>
							<li><a href="https://www.facebook.com/profile.php?id=100059394901669"><i class="icon-facebook3"></i></a></li>
							<li><a href="https://www.linkedin.com/in/fahad-binsadique-3b63211b5"><i class="icon-linkedin2"></i></a></li>
							<li><a href="https://www.reddit.com/user/tinybear07"><i class="icon-reddit"></i></a></li>
						</ul>

						</p>
				</div>
			</div>
		</div>
	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up22"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Easy PieChart -->
	<script src="js/jquery.easypiechart.min.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	
	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
</html>

