<?php

$con = mysqli_connect("localhost","fahad","Fahad@07","portfolio");